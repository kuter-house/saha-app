#  Instagram Tools (Develop)
[![Build Status](https://camo.githubusercontent.com/c9126cc8b292257866ca56cf0568fa257d200a83/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f76657273696f6e2d312e312e302d627269676874677265656e2e7376673f7374796c653d666c61742d737175617265)](https://www.ancreator.com/)  [![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://www.ancreator.com/)



instagram include unoffical API in folder ./lib.

will be updated soon. :)


## Script

Script Detailed.

| Tools | Description |  Script name | Status |
| :---         |  :---     |   :---     | :---     |
| Account Creator| For create multiple instagram account| accountCreator.js |  develop |
| Account Creator ( Edit ) | For create multiple instagram account with edit bio etc. | accountCreatorWithEdit.js | develop |
| Account Creator ( With Proxy ) | For create multiple instagram account using proxy | accountCreatorWithProxy.js | develop |
| Auto Followers | for auto follow ( data from database ) | autoFollowers.js | develop |
| Auto Followers FROM Txt | for auto follow ( data from txt )  | autoFollowersWithTxt.js | develop |
| Account Creator With Proxy | For create multiple account with proxy  | - | - |

## Lib

Lib detailed

u can check at folder lib.


## Contributing

- Fork this repo.
- Add new features or Fix features.
- Create a new pull request for this branch.

## License
[MIT](https://choosealicense.com/licenses/mit/)